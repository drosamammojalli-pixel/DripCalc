package com.ivsafe.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.InputType;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(15, 43, 68);
    private static final int BLUE = Color.rgb(21, 126, 190);
    private static final int TEAL = Color.rgb(0, 166, 155);
    private static final int BG = Color.rgb(241, 247, 251);
    private static final int INK = Color.rgb(35, 52, 67);
    private static final int MUTED = Color.rgb(105, 121, 135);

    private EditText volumeInput, durationInput;
    private Spinner factorSpinner;
    private TextView resultDrops, resultRate, resultSummary;
    private long lastBackPressed = 0L;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        showCalculator();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private GradientDrawable shape(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void gap(LinearLayout parent, int height) {
        View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }
    private LinearLayout card(String title, String subtitle, LinearLayout parent) {
        LinearLayout c = column(); c.setPadding(dp(17), dp(15), dp(17), dp(15));
        c.setBackground(shape(Color.WHITE, 19, Color.rgb(228, 236, 242), 1));
        if (title != null) c.addView(text(title, 18, NAVY, true));
        if (subtitle != null) {
            TextView s = text(subtitle, 12, MUTED, false);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(3); c.addView(s, sp);
        }
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.bottomMargin = dp(11); parent.addView(c, cp);
        return c;
    }
    private EditText makeInput(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(17); e.setTextColor(INK);
        e.setHintTextColor(Color.rgb(155, 169, 180)); e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(dp(13), dp(7), dp(13), dp(7));
        e.setBackground(shape(Color.rgb(250, 252, 254), 12, Color.rgb(216, 226, 234), 1));
        return e;
    }
    private void addField(LinearLayout parent, String label, View input) {
        LinearLayout f = column(); f.addView(text(label, 13, INK, true));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(48)); ip.topMargin = dp(6); f.addView(input, ip);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.topMargin = dp(11); parent.addView(f, fp);
    }
    private Button button(String label, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setTextColor(primary ? Color.WHITE : BLUE);
        b.setBackground(shape(primary ? BLUE : Color.rgb(239, 247, 251), 13, primary ? BLUE : Color.rgb(221, 235, 243), 1));
        return b;
    }

    private void showCalculator() {
        LinearLayout root = column(); root.setBackgroundColor(BG);
        LinearLayout header = column();
        GradientDrawable headerBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{NAVY, Color.rgb(20, 77, 111)});
        header.setBackground(headerBg); header.setPadding(dp(20), dp(13), dp(20), dp(14));
        header.addView(text("DripCalc", 26, Color.WHITE, true));
        TextView subtitle = text("IV drip-rate calculator", 13, Color.rgb(211, 231, 241), false);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2); subP.topMargin = dp(2); header.addView(subtitle, subP);
        root.addView(header);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false);
        LinearLayout content = column(); content.setPadding(dp(15), dp(13), dp(15), dp(9));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout inputCard = card("Infusion details", "Enter the prescribed volume, time and giving-set drop factor.", content);
        volumeInput = makeInput("e.g. 500");
        durationInput = makeInput("e.g. 2");
        factorSpinner = new Spinner(this);
        String[] factors = {"10 drops/mL", "15 drops/mL", "20 drops/mL", "60 drops/mL"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, factors);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); factorSpinner.setAdapter(adapter); factorSpinner.setSelection(2);
        factorSpinner.setBackground(shape(Color.rgb(250, 252, 254), 12, Color.rgb(216, 226, 234), 1));
        factorSpinner.setPadding(dp(10), 0, dp(10), 0);
        addField(inputCard, "Total fluid volume (mL)", volumeInput);
        addField(inputCard, "Infusion duration (hours)", durationInput);
        addField(inputCard, "Giving-set drop factor", factorSpinner);

        Button calculate = button("Calculate drip rate", true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(50)); bp.topMargin = dp(17); inputCard.addView(calculate, bp);
        Button reset = button("Reset", false);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(42)); rp.topMargin = dp(7); inputCard.addView(reset, rp);
        calculate.setOnClickListener(v -> calculate());
        reset.setOnClickListener(v -> { volumeInput.setText(""); durationInput.setText(""); factorSpinner.setSelection(2); clearResults(); });

        LinearLayout resultCard = card("Your drip rate", "Gravity infusion result", content);
        LinearLayout panel = column(); panel.setGravity(Gravity.CENTER);
        panel.setPadding(dp(12), dp(13), dp(12), dp(13));
        panel.setBackground(shape(Color.rgb(235, 248, 250), 16, Color.rgb(210, 236, 239), 1));
        resultDrops = text("—", 35, Color.rgb(0, 137, 145), true); resultDrops.setGravity(Gravity.CENTER);
        TextView dropsLabel = text("DROPS PER MINUTE  •  gtt/min", 10, MUTED, true); dropsLabel.setGravity(Gravity.CENTER);
        resultRate = text("— mL/hour", 18, NAVY, true); resultRate.setGravity(Gravity.CENTER);
        resultSummary = text("Enter values and calculate.", 12, MUTED, false); resultSummary.setGravity(Gravity.CENTER);
        panel.addView(resultDrops); gap(panel, 1); panel.addView(dropsLabel); gap(panel, 8); panel.addView(resultRate); gap(panel, 3); panel.addView(resultSummary);
        resultCard.addView(panel);

        TextView note = text("Use the drop factor printed on the giving set. Verify every result against the prescription and local clinical guidance.", 11, MUTED, false);
        note.setGravity(Gravity.CENTER); note.setPadding(dp(7), dp(1), dp(7), dp(5)); content.addView(note);

        TextView brand = text("#Med_Snacks", 13, TEAL, true); brand.setGravity(Gravity.CENTER);
        brand.setPadding(dp(12), dp(7), dp(12), dp(9)); root.addView(brand);
        setContentView(root);
    }

    private double parsePositive(String value) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException();
        double n = Double.parseDouble(value.trim().replace(',', '.'));
        if (Double.isNaN(n) || Double.isInfinite(n) || n <= 0) throw new IllegalArgumentException();
        return n;
    }
    private void hideKeyboard() {
        try { InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); imm.hideSoftInputFromWindow(volumeInput.getWindowToken(), 0); } catch (Exception ignored) {}
    }
    private void clearResults() {
        resultDrops.setText("—"); resultRate.setText("— mL/hour"); resultSummary.setText("Enter values and calculate.");
    }
    private void calculate() {
        try {
            double volume = parsePositive(volumeInput.getText().toString());
            double hours = parsePositive(durationInput.getText().toString());
            int[] factors = {10, 15, 20, 60};
            int pos = factorSpinner.getSelectedItemPosition();
            if (pos < 0 || pos >= factors.length) throw new IllegalArgumentException();
            int factor = factors[pos];
            double minutes = hours * 60.0;
            double exactDrops = (volume * factor) / minutes;
            double mlHour = volume / hours;
            if (Double.isNaN(exactDrops) || Double.isInfinite(exactDrops) || Double.isNaN(mlHour) || Double.isInfinite(mlHour)
                    || exactDrops > Long.MAX_VALUE || mlHour > Double.MAX_VALUE) throw new IllegalArgumentException();
            long drops = Math.round(exactDrops);
            resultDrops.setText(String.format(Locale.US, "%d", drops));
            resultRate.setText(String.format(Locale.US, "%.1f mL/hour", mlHour));
            resultSummary.setText(String.format(Locale.US, "%.1f mL over %.2f hour(s)  •  %d drops/mL", volume, hours, factor));
            if (drops == 0) resultSummary.setText("Rate is below 0.5 drop/min. Verify whether gravity infusion is appropriate.");
            hideKeyboard();
        } catch (Exception ex) {
            resultDrops.setText("Check input"); resultRate.setText("— mL/hour");
            resultSummary.setText("Enter valid positive volume and duration values, then select the correct drop factor.");
        }
    }

    @Override public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBackPressed < 2000) {
            super.onBackPressed();
        } else {
            lastBackPressed = now;
            Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
        }
    }
}
