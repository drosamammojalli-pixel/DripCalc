package com.ivsafe.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int navy = Color.rgb(16,42,67), blue = Color.rgb(22,119,200), pale = Color.rgb(241,246,250), dark = Color.rgb(35,49,62);
    private LinearLayout root, content, itemsBox;
    private EditText volumeInput, hoursInput, minutesInput, dropFactorInput;
    private TextView resultText;
    private JSONArray items = new JSONArray();
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("ivsafe_history", MODE_PRIVATE);
        showChecker();
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int p) { v.setPadding(p,p,p,p); }
    private EditText input(String hint, boolean decimal) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(15); e.setHint(hint);
        e.setInputType(decimal ? InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL : InputType.TYPE_CLASS_TEXT);
        e.setPadding(18,8,18,8); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.LTGRAY)); return e;
    }
    private Button button(String text) { Button b = new Button(this); b.setText(text); b.setAllCaps(false); return b; }
    private void base(String active) {
        root = column(); root.setBackgroundColor(pale);
        LinearLayout header = column(); header.setBackgroundColor(navy); pad(header,20);
        header.addView(label("IV SAFE",24,Color.WHITE,true)); header.addView(label("Compatibility • Interactions • Infusion",13,Color.rgb(210,225,238),false));
        root.addView(header);
        LinearLayout tabs = row(); tabs.setBackgroundColor(Color.WHITE);
        Button check = button("Checker"), history = button("History");
        check.setTextColor(active.equals("Checker") ? blue : dark); history.setTextColor(active.equals("History") ? blue : dark);
        tabs.addView(check,new LinearLayout.LayoutParams(0,-2,1)); tabs.addView(history,new LinearLayout.LayoutParams(0,-2,1));
        check.setOnClickListener(v -> showChecker()); history.setOnClickListener(v -> showHistory()); root.addView(tabs);
        ScrollView scroll = new ScrollView(this); content = column(); pad(content,16); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private void cardTitle(String title, String subtitle) {
        LinearLayout c = column(); c.setBackgroundColor(Color.WHITE); pad(c,16);
        c.addView(label(title,18,navy,true)); if (subtitle != null) { TextView s=label(subtitle,12,Color.GRAY,false); s.setPadding(0,4,0,0); c.addView(s); }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; content.addView(c,lp);
    }
    private LinearLayout addCard(String title, String subtitle) {
        LinearLayout c=column(); c.setBackgroundColor(Color.WHITE); pad(c,16); c.addView(label(title,18,navy,true));
        if(subtitle!=null) c.addView(label(subtitle,12,Color.GRAY,false));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; content.addView(c,lp); return c;
    }
    private void showChecker() {
        base("Checker");
        LinearLayout intro=addCard("Prescription checker","Add every medicine and IV solution involved in this infusion.");
        intro.addView(label("Important: compatibility checking is not yet connected to a validated clinical database. This version will not label combinations safe.",13,Color.rgb(160,70,20),true));
        LinearLayout drugCard=addCard("1. Medications and IV solutions","Add medicines and fluids to the same admixture / line being assessed.");
        itemsBox=column(); drugCard.addView(itemsBox); addItemRow();
        Button add=button("+ Add another drug or solution"); drugCard.addView(add); add.setOnClickListener(v -> addItemRow());
        LinearLayout calc=addCard("2. Infusion settings","Enter the total volume and planned administration time.");
        volumeInput=input("Total volume (mL)",true); hoursInput=input("Hours",true); minutesInput=input("Additional minutes",true); dropFactorInput=input("Giving set drop factor (drops/mL), e.g. 20",true);
        calc.addView(field("Total fluid volume (mL)",volumeInput)); calc.addView(field("Infusion duration",hoursInput)); calc.addView(field("Additional minutes",minutesInput)); calc.addView(field("Drop factor",dropFactorInput));
        Button analyze=button("ANALYZE & CALCULATE"); analyze.setTextColor(Color.WHITE); analyze.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=8; calc.addView(analyze,bp);
        resultText=label("Results will appear here.",14,dark,false); resultText.setPadding(0,14,0,0); calc.addView(resultText);
        analyze.setOnClickListener(v -> analyze());
        TextView note=label("Clinical safety: a drops/min calculation only describes the fluid delivery rate. It does not verify that a drug dose, concentration, diluent, or infusion rate is safe. Always verify against an approved local protocol and product information.",12,Color.DKGRAY,false); note.setPadding(4,4,4,18); content.addView(note);
    }
    private LinearLayout field(String title, EditText e) { LinearLayout l=column(); TextView t=label(title,13,dark,true); t.setPadding(0,10,0,2); l.addView(t); l.addView(e); return l; }
    private void addItemRow() {
        LinearLayout item=column(); item.setPadding(0,10,0,10);
        EditText name=input("Drug or IV solution name",false); EditText dose=input("Dose / amount (e.g. 40 mEq, 1 g, 500 mL)",false);
        item.addView(name); item.addView(dose);
        Button remove=button("Remove"); remove.setTextSize(12); item.addView(remove); remove.setOnClickListener(v -> itemsBox.removeView(item));
        itemsBox.addView(item);
    }
    private void analyze() {
        try {
            double volume=Double.parseDouble(volumeInput.getText().toString().trim());
            double h=hoursInput.getText().length()==0?0:Double.parseDouble(hoursInput.getText().toString().trim());
            double m=minutesInput.getText().length()==0?0:Double.parseDouble(minutesInput.getText().toString().trim());
            double factor=Double.parseDouble(dropFactorInput.getText().toString().trim());
            double totalMinutes=h*60+m;
            if(volume<=0 || totalMinutes<=0 || factor<=0) throw new Exception();
            double mlhr=volume/(totalMinutes/60.0); double drops=(volume*factor)/totalMinutes;
            String output=String.format(Locale.US,"INFUSION CALCULATION\nVolume: %.1f mL\nDuration: %.0f min\nRate: %.1f mL/hour\nDrop factor: %.1f drops/mL\nGravity rate: %.0f drops/min\n\nCOMPATIBILITY STATUS\nNOT CHECKED — no validated compatibility database is connected in this build. Do not assume any listed combination is compatible.\n\nDRUG-SPECIFIC INFUSION SAFETY\nNot assessed. Verify each drug's concentration, diluent, stability and maximum rate separately.",volume,totalMinutes,mlhr,factor,Math.round(drops));
            resultText.setText(output); saveHistory(output);
        } catch(Exception ex) { resultText.setText("Please enter valid positive values for volume, infusion time and drop factor. Use hours and additional minutes separately."); }
    }
    private void saveHistory(String result) {
        try { JSONArray a=new JSONArray(prefs.getString("entries","[]")); JSONObject o=new JSONObject(); o.put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date())); o.put("result",result); a.put(o); prefs.edit().putString("entries",a.toString()).apply(); } catch(Exception ignored) {}
    }
    private void showHistory() {
        base("History"); LinearLayout c=addCard("Previous calculations","Saved locally on this device.");
        try { JSONArray a=new JSONArray(prefs.getString("entries","[]")); if(a.length()==0) c.addView(label("No history yet.",14,Color.GRAY,false));
            for(int i=a.length()-1;i>=0;i--){ JSONObject o=a.getJSONObject(i); TextView t=label(o.optString("date")+"\n"+o.optString("result"),13,dark,false); t.setPadding(0,12,0,12); c.addView(t); View line=new View(this); line.setBackgroundColor(Color.LTGRAY); c.addView(line,new LinearLayout.LayoutParams(-1,1)); }
        } catch(Exception e) { c.addView(label("Unable to load history.",14,Color.RED,false)); }
        Button clear=button("Clear history"); c.addView(clear); clear.setOnClickListener(v->{prefs.edit().remove("entries").apply();showHistory();});
    }
}
