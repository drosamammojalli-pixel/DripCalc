package com.ivsafe.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.app.AlertDialog;
import android.text.InputType;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int navy=Color.rgb(15,39,63), blue=Color.rgb(26,115,190), bg=Color.rgb(244,247,251), ink=Color.rgb(34,49,63), muted=Color.rgb(105,119,132), green=Color.rgb(26,132,91), amber=Color.rgb(166,94,18), white=Color.WHITE;
    private LinearLayout root, content, itemsBox;
    private EditText volumeInput, durationInput, dropFactorInput;
    private TextView resultText;
    private final ArrayList<DrugRow> drugRows=new ArrayList<>();
    private SharedPreferences prefs;

    private static class DrugRow { EditText name, amount; LinearLayout container; }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("ivsafe_history",MODE_PRIVATE);
        showChecker();
    }

    private int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private GradientDrawable shape(int color,float radius,int strokeColor,int strokeWidth){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(strokeWidth>0)d.setStroke(dp(strokeWidth),strokeColor); return d;
    }
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void margins(View v,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(bottom);content.addView(v,p);}
    private EditText input(String hint,boolean numeric){
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(16);e.setTextColor(ink);e.setHint(hint);
        e.setInputType(numeric?InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL:InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setPadding(dp(14),dp(10),dp(14),dp(10));e.setBackground(shape(white,12,Color.rgb(218,226,234),1));return e;
    }
    private Button button(String s,boolean primary){
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(primary?white:navy);b.setBackground(shape(primary?blue:Color.rgb(235,241,247),12,primary?blue:Color.rgb(225,232,239),1));
        b.setMinHeight(dp(48));return b;
    }
    private LinearLayout card(String title,String subtitle){
        LinearLayout c=column();c.setPadding(dp(16),dp(16),dp(16),dp(16));c.setBackground(shape(white,16,Color.rgb(231,236,242),1));
        TextView h=text(title,18,navy,true);c.addView(h);
        if(subtitle!=null&&!subtitle.isEmpty()){TextView s=text(subtitle,13,muted,false);s.setPadding(0,dp(4),0,dp(12));c.addView(s);}else c.addView(space(8));
        margins(c,14);return c;
    }
    private View space(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return v;}
    private void base(String active){
        drugRows.clear();root=column();root.setBackgroundColor(bg);
        LinearLayout header=column();header.setPadding(dp(20),dp(18),dp(20),dp(18));header.setBackground(shape(navy,0,navy,0));
        header.addView(text("Safe-IV",26,white,true));TextView sub=text("IV compatibility  •  Interactions  •  Infusion",13,Color.rgb(210,224,238),false);sub.setPadding(0,dp(3),0,0);header.addView(sub);root.addView(header);
        LinearLayout tabs=row();tabs.setPadding(dp(12),dp(10),dp(12),dp(10));tabs.setBackgroundColor(white);
        Button check=button("Checker",active.equals("Checker")),history=button("History",active.equals("History"));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(44),1);cp.rightMargin=dp(6);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,dp(44),1);hp.leftMargin=dp(6);
        tabs.addView(check,cp);tabs.addView(history,hp);check.setOnClickListener(v->showChecker());history.setOnClickListener(v->showHistory());root.addView(tabs);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=column();content.setPadding(dp(14),dp(14),dp(14),dp(20));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    private void showChecker(){
        base("Checker");
        LinearLayout intro=card("Compatibility checker","Add the medicines and IV fluid(s) that will share the same bag or line.");
        TextView warning=text("DATABASE NOT CONNECTED  •  Compatibility is not being assessed in this version. Never assume a combination is safe based on the calculator.",12,amber,true);
        warning.setPadding(dp(12),dp(10),dp(12),dp(10));warning.setBackground(shape(Color.rgb(255,247,230),10,Color.rgb(245,220,170),1));intro.addView(warning);
        LinearLayout meds=card("1. Medicines & IV solutions","Enter the exact generic name, strength/concentration and amount where known.");
        itemsBox=column();meds.addView(itemsBox);addItemRow();
        Button add=button("＋  Add medicine or solution",false);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(8);meds.addView(add,ap);add.setOnClickListener(v->addItemRow());
        Button ivk=button("Open IVKompat compatibility database  ↗",true);LinearLayout.LayoutParams ivkp=new LinearLayout.LayoutParams(-1,-2);ivkp.topMargin=dp(10);meds.addView(ivk,ivkp);ivk.setOnClickListener(v->openIVKompat());
        TextView ivkNote=text("Opens the public IVKompat reference inside Safe-IV. Search combinations there and review the cited source for each result. This first connection is a web-based lookup; results are not yet automatically imported into the form.",12,muted,false);ivkNote.setPadding(dp(4),dp(8),dp(4),0);meds.addView(ivkNote);
        LinearLayout calc=card("2. Infusion calculator","Calculate the pump rate and gravity drip rate.");
        volumeInput=input("e.g. 500",true);durationInput=input("e.g. 1.5 for 1 hour 30 minutes",true);dropFactorInput=input("e.g. 20",true);
        calc.addView(field("Total volume (mL)",volumeInput));calc.addView(field("Infusion duration (hours, decimal allowed)",durationInput));calc.addView(field("Giving-set drop factor (drops/mL)",dropFactorInput));
        TextView hint=text("Common drop factors: 10, 15, 20 or 60 drops/mL. Check the giving-set packaging.",12,muted,false);hint.setPadding(0,dp(6),0,dp(8));calc.addView(hint);
        Button go=button("Calculate infusion",true);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2);gp.topMargin=dp(8);calc.addView(go,gp);
        resultText=text("Your infusion calculation will appear here.",14,ink,false);resultText.setPadding(dp(14),dp(14),dp(14),dp(14));resultText.setBackground(shape(Color.rgb(239,246,252),12,Color.rgb(213,228,241),1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(12);calc.addView(resultText,rp);
        go.setOnClickListener(v->analyze());
        TextView foot=text("Clinical note: the calculator only calculates fluid delivery rate. It does not validate the dose, final concentration, maximum drug rate, patient-specific suitability or compatibility.",12,muted,false);foot.setPadding(dp(4),dp(2),dp(4),dp(8));content.addView(foot);
    }

    private void openIVKompat(){
        LinearLayout box=column();box.setPadding(dp(8),dp(8),dp(8),dp(8));
        TextView note=text("IVKompat • Public IV compatibility reference\nCheck the exact administration method (diluent, Y-site, same bag or syringe) and open the cited evidence before applying a result.",12,muted,false);
        note.setPadding(dp(8),dp(4),dp(8),dp(8));box.addView(note);
        WebView web=new WebView(this);WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setLoadsImagesAutomatically(true);web.setWebViewClient(new WebViewClient());
        box.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("IVKompat database").setView(box).setNegativeButton("Close",(d,w)->{}).create();
        dialog.setOnDismissListener(d->web.destroy());
        dialog.show();dialog.getWindow().setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*0.88));
        web.loadUrl("https://ivkompat.github.io/");
    }

    private LinearLayout field(String title,EditText e){LinearLayout l=column();TextView t=text(title,13,ink,true);t.setPadding(0,dp(8),0,dp(6));l.addView(t);l.addView(e);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(6);l.setLayoutParams(p);return l;}
    private void addItemRow(){
        DrugRow r=new DrugRow();r.container=column();r.container.setPadding(0,dp(8),0,dp(12));
        r.name=input("Drug / solution name",false);r.amount=input("Amount / concentration (e.g. 1 g; 20 mEq in 500 mL)",false);
        r.container.addView(r.name);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=dp(7);r.container.addView(r.amount,mp);
        Button remove=button("Remove",false);remove.setTextSize(12);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,dp(38));bp.topMargin=dp(6);r.container.addView(remove,bp);
        remove.setOnClickListener(v->{itemsBox.removeView(r.container);drugRows.remove(r);});itemsBox.addView(r.container);drugRows.add(r);
    }
    private double parsePositive(EditText e,String label)throws Exception{
        String s=e.getText().toString().trim();if(s.isEmpty())throw new Exception("Enter "+label+".");
        double x=Double.parseDouble(s);if(Double.isNaN(x)||Double.isInfinite(x)||x<=0)throw new Exception("Enter a valid positive "+label+".");return x;
    }
    private void analyze(){
        try{
            double volume=parsePositive(volumeInput,"volume in mL"),hours=parsePositive(durationInput,"duration in hours"),factor=parsePositive(dropFactorInput,"drop factor");
            if(hours>168)throw new Exception("Please check the duration; it exceeds 7 days.");
            double minutes=hours*60.0,mlhr=volume/hours,drops=(volume*factor)/minutes;
            StringBuilder names=new StringBuilder();for(DrugRow r:drugRows){String n=r.name.getText().toString().trim(),a=r.amount.getText().toString().trim();if(!n.isEmpty()){if(names.length()>0)names.append("\n");names.append("• ").append(n);if(!a.isEmpty())names.append(" — ").append(a);}}
            String output=String.format(Locale.US,"INFUSION RESULT\nTotal volume: %.1f mL\nDuration: %.2f hours (%.0f minutes)\nPump rate: %.1f mL/hour\nDrop factor: %.0f drops/mL\nGravity rate: %.0f drops/min\n\nCOMPATIBILITY\nNOT CHECKED — a validated IV compatibility database is not connected yet.\n\nDRUG-SPECIFIC RATE / DOSE\nNot assessed. Verify each medicine's concentration, dose and maximum infusion rate separately.",volume,hours,minutes,mlhr,factor,Math.round(drops));
            resultText.setText(output);saveHistory(names.toString(),output);
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(resultText.getWindowToken(),0);
        }catch(Exception e){resultText.setText("CHECK YOUR INPUT\n"+(e.getMessage()==null?"Enter valid positive numbers for volume, duration and drop factor.":e.getMessage()));}
    }
    private void saveHistory(String drugs,String result){
        try{JSONArray a=new JSONArray(prefs.getString("entries","[]"));JSONObject o=new JSONObject();o.put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()));o.put("drugs",drugs);o.put("result",result);a.put(o);prefs.edit().putString("entries",a.toString()).apply();}catch(Exception ignored){}
    }
    private void showHistory(){
        base("History");LinearLayout c=card("Calculation history","Saved privately on this device.");
        try{JSONArray a=new JSONArray(prefs.getString("entries","[]"));if(a.length()==0)c.addView(text("No saved calculations yet.",14,muted,false));
            for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i);LinearLayout entry=column();entry.setPadding(0,dp(10),0,dp(10));entry.addView(text(o.optString("date"),12,muted,true));String drugs=o.optString("drugs");if(!drugs.isEmpty())entry.addView(text(drugs,13,ink,true));TextView res=text(o.optString("result"),13,ink,false);res.setPadding(0,dp(6),0,0);entry.addView(res);c.addView(entry);View line=new View(this);line.setBackgroundColor(Color.rgb(230,235,240));c.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}
        }catch(Exception e){c.addView(text("Unable to load history.",14,Color.RED,false));}
        Button clear=button("Clear history",false);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(12);c.addView(clear,p);clear.setOnClickListener(v->{prefs.edit().remove("entries").apply();showHistory();});
    }
}
