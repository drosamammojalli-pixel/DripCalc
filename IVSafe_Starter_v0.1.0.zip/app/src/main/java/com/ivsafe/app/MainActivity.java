package com.ivsafe.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.InputType;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(15, 43, 68);
    private static final int BLUE = Color.rgb(21, 126, 190);
    private static final int TEAL = Color.rgb(0, 166, 155);
    private static final int BG = Color.rgb(241, 247, 251);
    private static final int INK = Color.rgb(35, 52, 67);
    private static final int MUTED = Color.rgb(105, 121, 135);

    private EditText volumeInput, durationInput;
    private Spinner factorSpinner;
    private LinearLayout content;
    private SharedPreferences prefs;
    private TextView resultDrops, resultRate, resultSummary;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("dripcalc_history", MODE_PRIVATE);
        showCalculator();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    private GradientDrawable shape(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void addGap(LinearLayout parent, int height) {
        View gap = new View(this); parent.addView(gap, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void setupScreen(String subtitle, boolean historyPage) {
        LinearLayout root = column(); root.setBackgroundColor(BG);

        LinearLayout header = column();
        GradientDrawable headerBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{NAVY, Color.rgb(20, 77, 111)});
        header.setBackground(headerBg); header.setPadding(dp(22), dp(20), dp(22), dp(20));
        TextView brand = text("DripCalc", 29, Color.WHITE, true);
        header.addView(brand);
        TextView sub = text(subtitle, 14, Color.rgb(211, 231, 241), false);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2); subP.topMargin = dp(4); header.addView(sub, subP);
        root.addView(header);

        LinearLayout tabs = row(); tabs.setPadding(dp(14), dp(10), dp(14), dp(10)); tabs.setBackgroundColor(Color.WHITE);
        Button calc = tabButton("Calculator", !historyPage);
        Button history = tabButton("History", historyPage);
        tabs.addView(calc, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, dp(46), 1); hp.leftMargin = dp(9); tabs.addView(history, hp);
        calc.setOnClickListener(v -> showCalculator()); history.setOnClickListener(v -> showHistory());
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false);
        content = column(); content.setPadding(dp(16), dp(17), dp(16), dp(22));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private Button tabButton(String label, boolean selected) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setTextColor(selected ? Color.WHITE : NAVY);
        b.setBackground(shape(selected ? BLUE : Color.rgb(237, 243, 248), 14, selected ? BLUE : Color.rgb(229, 236, 242), 1));
        return b;
    }

    private LinearLayout card(String title, String subtitle) {
        LinearLayout c = column(); c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(shape(Color.WHITE, 20, Color.rgb(228, 236, 242), 1));
        if (title != null) c.addView(text(title, 19, NAVY, true));
        if (subtitle != null) { TextView s = text(subtitle, 13, MUTED, false); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(5); c.addView(s, p); }
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.bottomMargin = dp(14); content.addView(c, cp);
        return c;
    }

    private EditText makeInput(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(18); e.setTextColor(INK); e.setHintTextColor(Color.rgb(155, 169, 180)); e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(dp(14), dp(11), dp(14), dp(11));
        e.setBackground(shape(Color.rgb(250, 252, 254), 12, Color.rgb(216, 226, 234), 1));
        return e;
    }

    private LinearLayout field(String title, View input) {
        LinearLayout f = column(); f.addView(text(title, 14, INK, true));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52)); p.topMargin = dp(8); f.addView(input, p);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.topMargin = dp(17); f.setLayoutParams(fp);
        return f;
    }

    private Button actionButton(String label, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(16); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.WHITE : BLUE);
        b.setBackground(shape(primary ? BLUE : Color.rgb(239, 247, 251), 14, primary ? BLUE : Color.rgb(221, 235, 243), 1));
        return b;
    }

    private void showCalculator() {
        setupScreen("IV drip-rate calculator", false);

        LinearLayout intro = card(null, null);
        TextView eyebrow = text("GRAVITY INFUSION", 11, TEAL, true); eyebrow.setLetterSpacing(0.08f); intro.addView(eyebrow);
        TextView heading = text("Calculate your drip rate", 22, NAVY, true); LinearLayout.LayoutParams hP = new LinearLayout.LayoutParams(-1, -2); hP.topMargin = dp(5); intro.addView(heading, hP);
        TextView description = text("Enter the bag volume, infusion time and the drop factor printed on your giving set.", 14, MUTED, false);
        LinearLayout.LayoutParams dP = new LinearLayout.LayoutParams(-1, -2); dP.topMargin = dp(7); intro.addView(description, dP);

        LinearLayout inputCard = card("Infusion details", "All three values are required.");
        volumeInput = makeInput("e.g. 500");
        durationInput = makeInput("e.g. 2");
        factorSpinner = new Spinner(this);
        String[] factors = {"10 drops/mL", "15 drops/mL", "20 drops/mL", "60 drops/mL"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, factors);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); factorSpinner.setAdapter(adapter); factorSpinner.setSelection(2);
        factorSpinner.setBackground(shape(Color.rgb(250, 252, 254), 12, Color.rgb(216, 226, 234), 1));
        factorSpinner.setPadding(dp(12), dp(4), dp(12), dp(4));
        inputCard.addView(field("Total fluid volume (mL)", volumeInput));
        inputCard.addView(field("Infusion duration (hours)", durationInput));
        inputCard.addView(field("Giving-set drop factor", factorSpinner));

        Button calculate = actionButton("Calculate drip rate", true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54)); bp.topMargin = dp(22); inputCard.addView(calculate, bp);
        Button reset = actionButton("Reset values", false); LinearLayout.LayoutParams resetP = new LinearLayout.LayoutParams(-1, dp(46)); resetP.topMargin = dp(8); inputCard.addView(reset, resetP);
        calculate.setOnClickListener(v -> calculate());
        reset.setOnClickListener(v -> { volumeInput.setText(""); durationInput.setText(""); factorSpinner.setSelection(2); clearResults(); });

        LinearLayout resultCard = card("Your calculated rate", "Check the result against the prescription and giving-set packaging.");
        LinearLayout resultPanel = column(); resultPanel.setGravity(Gravity.CENTER);
        resultPanel.setPadding(dp(12), dp(18), dp(12), dp(18));
        resultPanel.setBackground(shape(Color.rgb(235, 248, 250), 16, Color.rgb(210, 236, 239), 1));
        resultDrops = text("—", 36, Color.rgb(0, 137, 145), true); resultDrops.setGravity(Gravity.CENTER);
        TextView dropsLabel = text("DROPS PER MINUTE  (gtt/min)", 11, MUTED, true); dropsLabel.setGravity(Gravity.CENTER); dropsLabel.setLetterSpacing(0.05f);
        resultRate = text("— mL/hour", 19, NAVY, true); resultRate.setGravity(Gravity.CENTER);
        resultSummary = text("Your result will appear here.", 13, MUTED, false); resultSummary.setGravity(Gravity.CENTER);
        resultPanel.addView(resultDrops); addGap(resultPanel, 2); resultPanel.addView(dropsLabel); addGap(resultPanel, 12); resultPanel.addView(resultRate); addGap(resultPanel, 5); resultPanel.addView(resultSummary);
        LinearLayout.LayoutParams panelP = new LinearLayout.LayoutParams(-1, -2); panelP.topMargin = dp(14); resultCard.addView(resultPanel, panelP);

        LinearLayout formula = card("Formula", null);
        formula.addView(text("gtt/min = (Volume × Drop factor) ÷ Total time in minutes", 14, INK, true));
        TextView caution = text("Use the drop factor printed on the giving set. The drip rate is rounded to the nearest whole drop. This calculator does not verify medication doses, compatibility or patient-specific infusion prescriptions. Always independently verify the result.", 12, MUTED, false);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(10); formula.addView(caution, cp);
    }

    private void hideKeyboard() {
        try { InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); imm.hideSoftInputFromWindow(volumeInput.getWindowToken(), 0); } catch (Exception ignored) {}
    }

    private void clearResults() {
        resultDrops.setText("—"); resultRate.setText("— mL/hour"); resultSummary.setText("Your result will appear here.");
    }

    private double parsePositive(String value) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException();
        double n = Double.parseDouble(value.trim().replace(',', '.'));
        if (Double.isNaN(n) || Double.isInfinite(n) || n <= 0) throw new IllegalArgumentException();
        return n;
    }

    private void calculate() {
        try {
            double volume = parsePositive(volumeInput.getText().toString());
            double hours = parsePositive(durationInput.getText().toString());
            int[] availableFactors = {10, 15, 20, 60};
            int position = factorSpinner.getSelectedItemPosition();
            if (position < 0 || position >= availableFactors.length) throw new IllegalArgumentException();
            int factor = availableFactors[position];
            double totalMinutes = hours * 60.0;
            double exactDrops = (volume * factor) / totalMinutes;
            double mlHour = volume / hours;
            if (Double.isNaN(exactDrops) || Double.isInfinite(exactDrops) || Double.isNaN(mlHour) || Double.isInfinite(mlHour)) throw new IllegalArgumentException();
            long drops = Math.round(exactDrops);
            resultDrops.setText(String.format(Locale.US, "%d", drops));
            resultRate.setText(String.format(Locale.US, "%.1f mL/hour", mlHour));
            resultSummary.setText(String.format(Locale.US, "%.1f mL over %.2f hour(s)  •  %d drops/mL", volume, hours, factor));
            if (drops == 0) resultSummary.setText("Calculated rate is below 0.5 drop/min; gravity delivery may not be practical. Verify the prescribed method.");
            hideKeyboard();
            String saved = String.format(Locale.US, "%.1f mL | %.2f hours | %d drops/mL | %d drops/min | %.1f mL/hour", volume, hours, factor, drops, mlHour);
            saveHistory(saved);
        } catch (Exception ex) {
            resultDrops.setText("Check input"); resultRate.setText("— mL/hour");
            resultSummary.setText("Enter a valid positive fluid volume and infusion duration. Use numbers only, and select the correct drop factor.");
        }
    }

    private void saveHistory(String result) {
        try {
            JSONArray a = new JSONArray(prefs.getString("entries", "[]")); JSONObject o = new JSONObject();
            o.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date()));
            o.put("result", result); a.put(o);
            while (a.length() > 50) { JSONArray trimmed = new JSONArray(); for (int i = 1; i < a.length(); i++) trimmed.put(a.get(i)); a = trimmed; }
            prefs.edit().putString("entries", a.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void showHistory() {
        setupScreen("Your saved calculations", true);
        LinearLayout c = card("Calculation history", "Saved privately on this device. No account or internet connection is needed.");
        try {
            JSONArray a = new JSONArray(prefs.getString("entries", "[]"));
            if (a.length() == 0) {
                TextView empty = text("No calculations yet. Your completed calculations will appear here.", 14, MUTED, false);
                empty.setPadding(0, dp(14), 0, dp(8)); c.addView(empty);
            }
            for (int i = a.length() - 1; i >= 0; i--) {
                JSONObject o = a.getJSONObject(i);
                LinearLayout item = column(); item.setPadding(0, dp(12), 0, dp(12));
                item.addView(text(o.optString("date"), 12, TEAL, true));
                TextView details = text(o.optString("result"), 14, INK, false); LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2); dp.topMargin = dp(4); item.addView(details, dp);
                c.addView(item);
                View line = new View(this); line.setBackgroundColor(Color.rgb(230, 237, 242)); c.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
            }
        } catch (Exception e) { c.addView(text("Unable to load history.", 14, Color.RED, false)); }
        Button clear = actionButton("Clear history", false); LinearLayout.LayoutParams clearP = new LinearLayout.LayoutParams(-1, dp(46)); clearP.topMargin = dp(14); c.addView(clear, clearP);
        clear.setOnClickListener(v -> { prefs.edit().remove("entries").apply(); showHistory(); });
    }
}
