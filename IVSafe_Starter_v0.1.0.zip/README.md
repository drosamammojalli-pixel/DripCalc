# DripCalc 1.2.0

A free, offline Android gravity IV drip-rate calculator.

## What's new in 1.2.0
- Shorter, more compact single-screen calculator.
- Removed the History tab and saved-history interface.
- Added the #Med_Snacks brand at the bottom of the app.
- Press Back twice within two seconds to exit, reducing accidental exits.

## Features
- Calculates gravity drip rate in drops/minute (gtt/min).
- Calculates equivalent fluid rate in mL/hour.
- Supports giving-set drop factors of 10, 15, 20 and 60 drops/mL.
- Accepts infusion duration in hours, including decimal values (for example, 1.5 hours).
- Works offline; no account, subscription, API key or internet access required.

## Formula

`gtt/min = (Volume in mL × Drop factor in drops/mL) ÷ Total time in minutes`

`mL/hour = Volume in mL ÷ Infusion time in hours`

The drops/min result is rounded to the nearest whole drop. Decimal commas are accepted as decimal separators.

## Example test

- Volume: 500 mL
- Duration: 2 hours
- Drop factor: 20 drops/mL
- Expected: 83 drops/min and 250 mL/hour

## Build

Run the **Build DripCalc APK** workflow in GitHub Actions. The workflow builds a debug APK and uploads it as `DripCalc-APK`.

## Clinical note

Use the drop factor printed on the giving set. This app calculates fluid delivery rate only; it does not validate medication doses, concentrations, drug stability, patient-specific suitability or prescribed infusion rates. Independently verify the result and monitor the infusion at the bedside.
