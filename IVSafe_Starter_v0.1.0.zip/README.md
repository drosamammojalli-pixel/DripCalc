# IV Safe – starter project (v0.1.0)

Native Android Java application. Package: `com.ivsafe.app`.

## Current build
- One Checker screen and one History screen.
- Add/remove multiple drug or IV-solution entries.
- Calculate mL/hour and gravity drops/minute from volume, duration and giving-set drop factor.
- Save calculation results locally.
- Explicitly reports compatibility as NOT CHECKED. No combinations are marked compatible or incompatible because a validated, licensed compatibility dataset/API has not yet been integrated.

## Build
Requires JDK 17, Android SDK platform 35, and Gradle 8.7+.

```bash
gradle :app:assembleDebug
```

GitHub Actions workflow: `.github/workflows/android.yml`. Push to GitHub or run the workflow manually; download the `IV-Safe-debug-apk` artifact.

## Clinical safety and next development step
Before adding compatibility decisions, select and obtain lawful access to a validated source/API covering drug–fluid admixture, Y-site, syringe and drug–drug interaction data. The engine must distinguish these routes and return UNKNOWN when evidence is absent. Drug-specific dosing, concentration, stability and infusion-rate rules require separately sourced product/protocol data. Never infer compatibility from a simple drug-name match.
