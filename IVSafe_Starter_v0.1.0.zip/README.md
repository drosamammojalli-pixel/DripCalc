# Safe-IV v0.3.0 — IVKompat web lookup integration

Native Android Java application. Package: `com.ivsafe.app`.

## Included
- App/repository display name: Safe-IV.
- Checker and History tabs.
- Add/remove multiple medicines and IV solutions.
- Infusion calculator: total volume, duration in decimal hours, drop factor; calculates mL/hour and drops/minute.
- Local on-device calculation history.
- IVKompat public reference website opens inside the app through an embedded WebView. Internet permission is required.

## Important integration limitation
IVKompat is currently connected as an in-app web reference, not as a machine-readable API. Safe-IV does not automatically submit the entered combinations to IVKompat or parse its results. The user must search the combinations in IVKompat and inspect the cited evidence. Do not treat missing results as compatibility. An automated native integration requires a documented/stable API or permission to consume the underlying structured dataset and confirmation of its reuse terms.

IVKompat describes itself as a reference compiled from official labels, hospital compatibility charts, manufacturer testing and clinical research. It lists entries for drug+diluent, Y-site, same-bag and same-syringe checks, and shows sources with results. Always verify the exact product, concentration, diluent and administration method.

## Build
Requires JDK 17, Android SDK platform 35, and Gradle 8.9 or compatible.

```bash
gradle :app:assembleDebug
```

## Clinical safety
The infusion calculator only calculates fluid delivery rate. It does not validate a medicine dose, final concentration, maximum infusion rate, patient-specific suitability or compatibility.
