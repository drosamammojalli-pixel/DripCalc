# DripCalc 1.1.0

A free, offline Android gravity IV drip-rate calculator.

## Features
- Calculates gravity drip rate in drops/minute (gtt/min).
- Calculates equivalent fluid rate in mL/hour.
- Supports giving-set drop factors of 10, 15, 20 and 60 drops/mL.
- Accepts infusion duration in hours, including decimal values (for example, 1.5 hours).
- Saves the 50 most recent calculations locally on the device.
- Updated visual interface and custom teal drop/calculator launcher icon.
- No account, subscription, API key, database connection or internet access required.

## Formula

`gtt/min = (Volume in mL × Drop factor in drops/mL) ÷ Total time in minutes`

`mL/hour = Volume in mL ÷ Infusion time in hours`

The drops/min result is rounded to the nearest whole drop. Decimal commas are accepted as decimal separators.

## Example test

- Volume: 500 mL
- Duration: 2 hours
- Drop factor: 20 drops/mL
- Expected: 83 drops/min and 250 mL/hour

## Build

The GitHub Actions workflow builds a debug APK when manually run or when changes are pushed to `main` / `master`.

## Clinical note

Use the drop factor printed on the giving set. This app calculates fluid delivery rate only; it does not validate medication doses, concentrations, drug stability, patient-specific suitability or prescribed infusion rates. Independently verify the result and monitor the infusion at the bedside.
